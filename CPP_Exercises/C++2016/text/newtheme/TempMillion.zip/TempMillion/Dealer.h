/*
 *  Dealer.h
 *  PlayingCard
 *
 *  Created by 下薗 真一 on 09/04/12.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

class Dealer {
	CardSet theDeck;
	CardSet discarded;
	Card discardedRank;
	
	Player * players[10];
	int numberOfPlayers;
	int pauper;
	int turn;
	int leaderIndex;
	
//	Player * ranking[10];
	bool noMillionaire;
public:
	Dealer::Dealer();

	void Dealer::newGame();
	bool Dealer::regist(Player *);
	bool Dealer::deal(int);
	bool Dealer::dealAll();
	void Dealer::letemShow();
	
	int Dealer::howManyPlayers() { return numberOfPlayers; }
	int Dealer::howManyParticipants();
		
	void Dealer::hailThePlayers() { return; }
	void Dealer::showDiscardedAround();
	void Dealer::chooseLeader();
	
	void Dealer::promptNext(CardSet & t);
	
	bool Dealer::accept(CardSet & opened);
	bool Dealer::checkRankUniqueness(CardSet &);
	Card Dealer::getCardRank(CardSet &);

//	void Dealer::replaceWith(CardSet &, CardSet &);
	CardSet & Dealer::discardPile();
	void Dealer::clearDiscardPile();
	bool Dealer::playerInTurnIsLeader();
	void Dealer::setAsLeader();
	Player & Dealer::player(int);
	int Dealer::numberOfFinishedPlayers() ;
	void withdrawPlayer(int);
	
	Player & Dealer::playerInTurnFinished();
	
	Player & Dealer::playerInTurn();
	Player & Dealer::nextPlayer();
	Player & Dealer::currentLeader();
	
};
