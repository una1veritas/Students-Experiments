/*
 *  Player.cpp
 *  PlayingCard
 *
 *  Created by 下薗 真一 on 09/04/12.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
#include <stdio.h>
#include <string.h>

#include <iostream>
#include <string>

#include "Card.h"
#include "CardSet.h"
#include "Player.h"

Player::Player(char * given) {
	hand.makeempty();
	name = given;  // constructor of std::string casts char array to std::string
	return;
}

Player::Player(std::string given) {
	hand.makeempty();
	name = given;
	return;
}


std::string Player::playerName() { 
	return name; 
}


std::string Player::printString() const {
	std::string tmp;
	tmp = name + ": ";
	tmp += hand.printString();
	return tmp;
}

void Player::clearHand() {
	hand.makeempty();
}

bool Player::isEmptyHanded() {
	return hand.isempty();
}

bool Player::pickup(Card c) {
	return hand.insert(c);
}

bool Player::takeCards(CardSet & s) {
	Card tmp;
	while (!s.isempty()) {
		s.pickup(&tmp, 0);
		hand.insert(tmp);
	}
	return true;
}

bool Player::approve(CardSet & pile) {
  // Card[] c = pile.operator();
	return true;
}

bool Player::follow(CardSet & pile, CardSet & s) {
  s.makeempty();
  //pileには場にある一番新しいカードだけがある
  Card tmp;
  sleep(2);
  if(name == "TDN"){
    // sleep(1);
    Card now, min;
    now = pile.operator[](0); //場のカードが判明
    CardSet sortset;
    sort(sortset); //sorted
    //sortset.print();sleep(2);
    //**********場が０枚**************
    if(pile.size() == 0){
      //printf("トップです\n");
      /*for(int i = 0; i < sortset.size(); i++){
	sortset.pickup(&tmp, i);
	hand.remove(tmp);
	s.insert(tmp);
	break;
	}*/
      
      //1/3までで３枚組があるか探す;あったら出す
      for(int i = 0; i < sortset.size() /3; i++){ 
	if(sortset[i].getrank() == sortset[i+1].getrank()){
	  if(sortset[i+1].getrank() == sortset[i+2].getrank()){ //３枚組あり
	    sortset.pickup(&tmp, i);
	    hand.remove(tmp);
	    s.insert(tmp);
	    sortset.pickup(&tmp, i);
	    hand.remove(tmp);
	    s.insert(tmp);
	    sortset.pickup(&tmp, i);
	    hand.remove(tmp);
	    s.insert(tmp);
	    //  sleep(2);
	    return true;
	  }
	  /*else if(sortset[sortset.size()-1].isJoker()){ //２枚組あり&&Jokerあり
	    sortset.pickup(&tmp, i);
	    hand.remove(tmp);
	    s.insert(tmp);
	    sortset.pickup(&tmp, i);
	    hand.remove(tmp);
	    s.insert(tmp);
	    sortset.pickup(&tmp, sortset.size()-1);
	    hand.remove(tmp);
	    s.insert(tmp);
	    return true
	    }*/
	}
      }

      //半分までで２枚組があるか探す;あったら２枚出す
      for(int i = 0; i < sortset.size() / 2; i++){ 
	if(sortset[i].getrank() == sortset[i+1].getrank()){
	  sortset.pickup(&tmp, i);
	  hand.remove(tmp);
	  s.insert(tmp);
	  sortset.pickup(&tmp, i);
	  hand.remove(tmp);
	  s.insert(tmp);
	  //  sleep(2);
	  return true;
	}
      }
      
      //半分までで組がないなら最弱を１枚出す
      sortset.pickup(&tmp, 0);
      hand.remove(tmp);
      s.insert(tmp);
    }
    //**********場が１枚**************
    else if(pile.size() == 1){
      //出せるなら出す
      //printf("場に一枚カードがあります\n");
      for(int i = 0; i < sortset.size(); i++){
	if(sortset[i].isGreaterThan(now)){
	  sortset.pickup(&tmp, i);
	  hand.remove(tmp);
	  s.insert(tmp);
	  break;
	}
      }
    }
    //**********場が２枚**************
    else if(pile.size() == 2){
      //出せるなら出す
      for(int i = 0; i < sortset.size(); i++){
	if(sortset[i].isGreaterThan(now))
	  if(sortset[i].getrank() == sortset[i+1].getrank()){
	    sortset.pickup(&tmp, i);
	    hand.remove(tmp);
	    s.insert(tmp);
	    sortset.pickup(&tmp, i);
	    hand.remove(tmp);
	    s.insert(tmp);
	    //  sleep(2);
	    return true;
	  }
	//Jokerがあったら&&強いカードが必要
	if(sortset[i].isJoker())
	  ;
      }     
    }
    //**********場が３枚**************
    else if(pile.size() == 3){
      //３枚組があるか探す;あったら３枚出す
      for(int i = 0; i < sortset.size(); i++){ 
	if(sortset[i].isGreaterThan(now)){ //２枚組あり
	  if(sortset[i].getrank() == sortset[i+1].getrank()){
	    if(sortset[i+1].getrank() == sortset[i+2].getrank()){ //３枚組あり
	      sortset.pickup(&tmp, i);
	      hand.remove(tmp);
	      s.insert(tmp);
	      sortset.pickup(&tmp, i);
	      hand.remove(tmp);
	      s.insert(tmp);
	      sortset.pickup(&tmp, i);
	      hand.remove(tmp);
	      s.insert(tmp);
	      //  sleep(2);
	      return true;
	    }
	    else if(sortset[sortset.size()-1].isJoker()){ //２枚組あり&&Jokerあり
	      sortset.pickup(&tmp, sortset.size()-1);
	      hand.remove(tmp);
	      s.insert(tmp);	    
	      sortset.pickup(&tmp, i);
	      hand.remove(tmp);
	      s.insert(tmp);
	      sortset.pickup(&tmp, i);
	      hand.remove(tmp);
	      s.insert(tmp);
	      //sortset.pickup(&tmp, sortset.size()-1);
	      //hand.remove(tmp);
	      //s.insert(tmp);
	      return true;
	      }
	  }
	}
      }
    }
    return true;
  }

  if(name == "ErikaSama"){
    //sleep(1);

	Card checkcard;
	bool check = false;
	bool find = false;
	int i, j, k, l, m;
	int locatenum[4];
	int cardnum = 1;
	bool doub = false;
	int doubcard[13];
	int doubnum = 0;

	locatenum[0] = -1;
	s.makeempty();

	  ///// 場が零枚の場合 /////
	  if(pile.size() == 0) {
	    int cardrank = 12;	      
	    //printf("\n");
	    // 手持ちの中で弱いカードから出す（複数枚対応）
	    for(i = 0; i < hand.size(); i++) {
	      if(!hand[i].isJoker() && (hand[i].getrank()+10)%13 < cardrank) {
		locatenum[0] = i;
		cardnum = 1;
		checkcard.set(hand[i].getsuit(),hand[i].getrank());
		check = true;
		cardrank = (hand[i].getrank()+10)%13;
		//printf("cardrank = %d\n", (cardrank+3)%13);
	      }
	      else if(check = true && checkcard.getrank() == hand[i].getrank()) {
		//printf("double\n");
		locatenum[cardnum] = i-cardnum;
		cardnum++;
	      }
	    }
	  }
	  ///// 場が一枚の場合 /////
	  if(pile.size() == 1) {
	    if(!pile[0].isJoker()) {
	      //printf("\n");
	      // 場にでているカードより少し強いカードから出す＆複数枚カードは出さない
	      for(i = 1; i < 13-(pile[0].getrank()+10)%13 && find == false; i++) {
		//printf("rank = %d\n",pile[0].getrank()+i);
		for(j = 0; j < hand.size(); j++) {
		  if(find == false) {
		    if(((pile[0].getrank()+10)%13)+i == (hand[j].getrank()+10)%13) {
		      for(k = 0; k < doubnum; k++)
			if(doubcard[k] == (hand[j].getrank()+10)%13)
			  doub = true;
		      if(doub == false) {
			locatenum[0] = j;
			find = true;
		      }
		      doub = false;
		    }
		  }
		  else if(((pile[0].getrank()+10)%13)+i == (hand[j].getrank()+10)%13) {
		    //printf("\nif 0 : break\n");
		    find = false;
		    locatenum[0] = 0;
		    doubcard[doubnum]=(hand[j].getrank()+10)%13;
		    doubnum++;
		    break;
		  }
		  //printf("%d", j);
		}
	      }
	    }
	  }
	  ///// 場が二枚の場合 /////
	  if(pile.size() == 2) {
	    if(!pile[0].isJoker()) {
	      //printf("\n");
	      // 場にでているカードより少し強いカードから出す
	      for(i = 1; i < 13-(pile[0].getrank()+10)%13 && find == false; i++) {
		//printf("rank = %d\n",pile[0].getrank()+i);
		for(j = 0; j < hand.size() && find == false; j++){
		  if(((pile[0].getrank()+10)%13)+i == (hand[j].getrank()+10)%13) {
		    locatenum[0] = j;
		    for(l = j+1; l < hand.size() && find == false; l++) {
		      if(((pile[0].getrank()+10)%13)+i == (hand[l].getrank()+10)%13 ){
			locatenum[1] = l-1;
			cardnum++;
			find = true;
		      }
		    }
		  }
		}
	      }
	    }
	  }
	  ///// 場が三枚の場合 /////
	  if(pile.size() == 3) {
	    if(!pile[0].isJoker()) {
	      // printf("\n");
	      // 場にでているカードより少し強いカードから出す
	      for(i = 1; i < 13-(pile[0].getrank()+10)%13 && find == false; i++) {
		//printf("rank = %d\n",pile[0].getrank()+i);
		for(j = 0; j < hand.size() && find == false; j++){
		  if(((pile[0].getrank()+10)%13)+i == (hand[j].getrank()+10)%13) {
		    cardnum = 1;
		    locatenum[0] = j;
		    for(l = j+1; l < hand.size() && find == false; l++) {
		      if(((pile[0].getrank()+10)%13)+i == (hand[l].getrank()+10)%13 ){
			locatenum[1] = l-1;
			cardnum++;
			for(m = l+1; m < hand.size() && find == false; m++) {
			  if(((pile[0].getrank()+10)%13)+i == (hand[m].getrank()+10)%13 ){
			    locatenum[2] = m-2;
			    cardnum++;
			    find = true;
			  }
			}
		      }
		    }
		  }
		}
	      }
	    }
	  }

	for(i = 0; i < cardnum; i++) {
	  hand.pickup(&tmp, locatenum[i]); // anyway, choose a card.
	  s.insert(tmp);
	}

	// the card idential to tmp is already removed from the hand. 
	return true;
  }
  //sortset.print();
  //sleep(3);
  //std::cout << "sort:"; sort.print();
  //  sleep(10);
  //std::cout << "sort::"; hand.print();

  hand.pickup(&tmp, -1);
  s.insert(tmp);
  // the card idential to tmp is already removed from the hand.
  
  return true;
}

bool Player::sort(CardSet &sortset){

  int numcard = 53;
  Card sort[numcard];
  int length = 0;
  for(int i = 0; i < hand.size(); i++){
    sort[i] = hand[i];
    length++;
  }

  for(int i = 0; i < length; i++){
    //    Card c1 = hand[i];
    //    printf("#####");hand[i].print();
    for(int j = i+1; j < length; j++){
      //  Card c2 = hand[j];
      // hand[j].print();printf("#####\n");
      if(sort[i].isGreaterThan(sort[j])){
	Card temp = sort[i];
	sort[i] = sort[j];	
	sort[j] = temp;
	//	hand.print();
	//sleep(3);
      }
    }
  }

  //CardSet sortset;
  for(int i=0; i<length; i++){
    sortset.insert(sort[i]);
  }
  //  sortset.print();
  return true;
}
