/*
 *  Player.h
 *  PlayingCard
 *
 *  Created by 下薗 真一 on 09/04/12.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

class Player {
	CardSet hand;
	std::string name;
	
public:
	Player(char *);
	Player(std::string);
	~Player();
	std::string printString(void) const;
	void clearHand();
	bool isEmptyHanded();
	bool pickup(Card );
	bool takeCards(CardSet &);
	
	std::string playerName();
	bool follow(CardSet &, CardSet &);
	bool Player::approve(CardSet & );
	void cardSetOfSameRanks(CardSet &, int); /* follow()の際に複数のカードを探す::未実装 */	
	bool Player::sort(CardSet&);
};
