#include <iostream>

int main() {

  int num, num2;

  std::cin >> num >> num2;

  std::cout << "got numbers: " << num << ", " << num2 << std::endl; 


  return 0;
}
