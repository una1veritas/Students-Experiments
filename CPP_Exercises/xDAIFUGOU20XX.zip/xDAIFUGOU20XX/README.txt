■コンパイルの方法
c++ Card.cc CardSet.cc Dealer.cc Player.cc LittleThinkPlayer.cc ThinkTA1.o main.cc [RETURN]

